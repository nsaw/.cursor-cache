###############################################################################
# 				⚠️⚠️⚠️ LOCAL MASTER BACKUP -- DO NOT ERASE ⚠️⚠️⚠️
#									🧠 
#							.ENV CONFIGURATION 
# 
#
# VERSION: v0.4.7bak (Updated: 2025-07-08)
# ENVIRONMENT: production
#
# ⚠️ WARNING - CONFIG CONSOLIDATION IN EFFECT
# - 'OPENAI_API_KEY' is deprecated. Replace with scoped keys below.
# - 'SLACK_TEST_API_KEY' used only for isolated webhook tests.
# - ngrok usage is deprecated. Use Cloudflare tunnels where specified.
#
# 🔧 All configuration references must match `gpt-cursor-runner`, Expo, and server usage.
#
#
###############################################################################
#######################  THOUGHTMARKS PLATFORM   ############################
###############################################################################

### 🔥 FIREBASE CONFIGURATION
# Firebase WebApp (Replit)
VITE_FIREBASE_API_KEY=AIzaSyDtBzTLi6mbn2r4g6q1whX4LM-xHqXJg5Y
VITE_FIREBASE_APP_ID=1:371020564944:web:93929f807b43caaf9c91d5
VITE_FIREBASE_PROJECT_ID=thoughtmarks-25replit
# Firebase Expo (React Native)
# TODO: Confirm if same keys are reused or replaced for Expo

### 🧮 DATABASE (PostgreSQL via Neon)
SESSION_SECRET=xk0pWhnh4cF0PcTWSwPJU PJVxLAvMvzGDGGZ8EPTJBleXBrgpDdK7Ks0M26Fgw1U6cv5Am52vB4KHYnF0+g==
DATABASE_URL=postgresql://neondb_owner:npg_mzSZqcdtr4b1@ep-spring-shape-a5cbcfs2.us-east-2.aws.neon.tech/neondb?sslmode=require
PGDATABASE=neondb
PGHOST=ep-spring-shape-a5cbcfs2.us-east-2.aws.neon.tech
PGPORT=5432
PGUSER=neondb_owner
PGPASSWORD=npg_mzSZqcdtr4b1

### 🌐 TUNNELS - CLOUDFLARE & NGROK

# Cloudflare Tunnels
## Expo - Production
CLOUDFLARE_PUBLIC_EXPO_TUNNEL_HOSTNAME=expo.thoughtmarks.app
CLOUDFLARE_EXPO_TUNNEL_SERVICE=http://localhost:3333

## Expo - Dev
CLOUDFLARE_EXPO-DEV_TUNNEL_HOSTNAME=expo-dev.thoughtmarks.app
CLOUDFLARE_EXPO-DEV_TUNNEL_SERVICE=http://localhost:3031
LOCAL_EXPO-DEV_SERVICE=http://192.168.68.127:4000

## Runner - Production
CLOUDFLARE_PUBLIC_RUNNER_TUNNEL_HOSTNAME=runner.thoughtmarks.app
CLOUDFLARE_RUNNER_TUNNEL_SERVICE=http://localhost:5555

## Runner - Dev
CLOUDFLARE_RUNNER-DEV_TUNNEL_HOSTNAME=runner-dev.thoughtmarks.app
CLOUDFLARE_RUNNER-DEV_TUNNEL_SERVICE=http://localhost:5051

## Backend - Production
CLOUDFLARE_BACKEND_TUNNEL_HOSTNAME=mobile.thoughtmarks.app
CLOUDFLARE_BACKEND_TUNNEL_SERVICE=http://localhost:4001

## Backend - Dev
CLOUDFLARE_BACKEND-DEV_TUNNEL_HOSTNAME=mobile-dev.thoughtmarks.app
CLOUDFLARE_BACKEND-DEV_TUNNEL_SERVICE=http://localhost:4041

# Ngrok (Legacy / fallback)
NGROK_AUTH_TOKEN=2zEtqtpB4YaTdpQfpLf5cZunb8Y_2rstF1BT2zfiUeom5WqWc

### 🚀 RUNTIME CONFIG
PUBLIC_RUNNER_URL=https://gpt-cursor-runner.fly.dev
CURSOR_ENDPOINT_DEV=https://thoughtmarks.app:5555
CURSOR_ENDPOINT_PROD=https://gpt-cursor-runner.fly.dev
NODE_ENV=production
ENV=production

### 🔐 GOOGLE SERVICES
GOOGLE_ANDROID_CLIENT_ID=482692133923-uahvc6eshmr3p03mv8dl9vgk6vrl6b5v.apps.googleusercontent.com
GOOGLE_IOS_CLIENT_ID=482692133923-urb0tq0gcjbp06e26gimulhjp18kpcpb.apps.googleusercontent.com
GOOGLE_API_KEY=AIzaSyB2WTSR6ptuuLSfUfeQEnMZsJfMzzUmniQ

### 🍏 APPLE SERVICES
APPLE_BUNDLE_ID=com.Thoughtmarks.mobile
APPLE_TEAM_ID=72SVDSY448
APPLE_KEY_ID=7SB8G29F2D
APPLE_PRIVATE_KEY=-----BEGIN PRIVATE KEY-----
MIGTAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBHkwdwIBAQQg3z7rsdd6MogcniLb
APpq2LahZ0MKBQGuHebNgl2DuJ2gCgYIKoZIzj0DAQehRANCAATqMLgi1uLeTy8S
QwCFGTUr+HNdJNUGlWEDH9eW2m0mt84zfDmENYXp+L1eH4ja16NgkibB0TVEQF+1
btDKuewS
-----END PRIVATE KEY-----
APPLE_NOTIFICATION_ENDPOINT=https://thoughtmarksapp.com/api/auth/apple/notifications

### ✉️ COMMUNICATION & MARKETING
SLACK_TEST_API_KEY=sk_test_5102NARGTLFReEjHmDcaDfOd
MAILCHIMP_API_KEY=50c6bcd15ef81a520d8c12ba0707b330-us21
SENDGRID_API_KEY=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

### 💳 STRIPE PAYMENT
STRIPE_SECRET_KEY=sk_test_5102NARGTLFReEjHmDcaDfOdjXiEY3QNtLYUaJck3NFxFXSMvmYMYOnnPxuLEGJb54wN5gXUnHBLBI5QWrPwo08b8R800hxZajOr3
VITE_STRIPE_PUBLIC_KEY=pk_test_5102NARGTLFReEjHmFdCnQBcfYSKizs77Y89LAdSzOG49ia0iN8NmDzeMgsNNjSoYcJ6XQwS0OjPclrpUJ9bP5I300fewYvd1q

### 💬 SLACK BOT & APP CONFIGURATION
# Slack App: GPT-Cursor Runner
SLACK_APP_ID=A09469H0C2K
SLACK_CLIENT_ID=9175632787408.9142323012087
SLACK_CLIENT_SECRET=a4eb8085215e7c74976c46880a74fa46
SLACK_BOT_TOKEN=xoxb-9175632787408-9148938089411-NASu77mZyxisZTHPtZyrXTqI
SLACK_APP_TOKEN=xapp-1-A09469H0C2K-9153609992933-5082b0c0f454236fe263839711e7ea6bf2311cef5eb8ea4315e397de94944dd0
SLACK_SIGNING_SECRET=8d27e59af8be27e946bea8ee2f63d1db
SLACK_REFRESH_TOKEN=xoxe-1-My0xLTkxNzU2MzI3ODc0MDgtOTE1Njg3MjgzMDM4Ni05MTU2ODcyODYwMjkwLTQzOTRhZDM0OTAwM2M0Y2JkMmYwY2QwMjY5MGFjZGExMWRkYzFmNDI2MjkxYjA0OTgwMjRlY2RhZGM1NGRkZmY
SLACK_ACCESS_TOKEN=xoxe.xoxp-1-Mi0yLTkxNzU2MzI3ODc0MDgtOTE3NTYzMjgxODc1Mi05MTU2ODcyODMwMzg2LTkxNTY4NzI4NDQ2NzQtMGU1ZmRjYWM4YTM5YjIzNDYxMmZkZDRhMTZlZTQ5OTRkNDM5OGY0MTNmZDZiNjUzOTU5NTkzOThmMzM2ODg5ZQ
SLACK_VERIFICATION_TOKEN=3up2OCWrSjmEHwXzZHzF8V6S

### 🧠 OPENAI SERVICE & PROJECT KEYS
# Scoped API Keys by Service
# App - Thoughtmarks Mobile
OPENAI_APP_AITOOLS_API_KEY=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

# Runner Bot
OPENAI_RUNNER_API_KEY=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

# Cursor Project
OPENAI_CURSOR_API_KEY=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

### 🔁 BACKCOMPAT MAPPINGS (Optional chaining, not required unless loading env via config parser)
SLACK_APP_TOKEN=xapp-1-A09469H0C2K-9153609992933-5082b0c0f454236fe263839711e7ea6bf2311cef5eb8ea4315e397de94944dd0
SLACK_BOT_OAUTH_TOKEN=xoxb-9175632787408-9148938089411-NASu77mZyxisZTHPtZyrXTqI
SLACK_SIGNING_SECRET=8d27e59af8be27e946bea8ee2f63d1db
OPENAI_API_SLACK_PROJ_KEY=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
OPENAI_API_SLACK_SERV_KEY=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
## SLACK_BOT_TOKEN=${SLACK_BOT_TOKEN} same as oauth bot token?
SLACK_BOT_TOKEN=xoxb-9175632787408-9148938089411-NASu77mZyxisZTHPtZyrXTqI

###############################################################################
####################### 		END // THOUGHTMARKS     	    #########################
###############################################################################