#slash_commands:

/dashboard
View GPT-Cursor Runner dashboard and stats
View dashboard
https://gpt-cursor-runner.fly.dev/slack/commands

/patch-approve
Approve the next pending GPT patch
Approve patch
https://gpt-cursor-runner.fly.dev/slack/commands

/patch-revert
Revert the last applied patch
Revert patch
https://gpt-cursor-runner.fly.dev/slack/commands

/pause-runner
Pause the GPT-Cursor Runner
Pause runner
https://gpt-cursor-runner.fly.dev/slack/commands

/restart-runner
Restart the GPT-Cursor Runner service
Restart service
https://gpt-cursor-runner.fly.dev/slack/commands

/restart-runner-gpt
Restart GPT integration specifically
Restart GPT
https://gpt-cursor-runner.fly.dev/slack/commands

/continue-runner
Resume the paused runner
Continue runner
https://gpt-cursor-runner.fly.dev/slack/commands

/status
Check current runner status and health
Check status
https://gpt-cursor-runner.fly.dev/slack/commands

/show-roadmap
Display development roadmap
Show roadmap
https://gpt-cursor-runner.fly.dev/slack/commands

/roadmap
Show project roadmap and milestones
View roadmap
https://gpt-cursor-runner.fly.dev/slack/commands

/kill-runner
Force stop the runner (emergency)
Kill runner
https://gpt-cursor-runner.fly.dev/slack/commands

/toggle-runner-on
Enable the runner
Enable runner
https://gpt-cursor-runner.fly.dev/slack/commands

/toggle-runner-off
Disable the runner
Disable runner
https://gpt-cursor-runner.fly.dev/slack/commands

/toggle-runner-auto
Toggle automatic patch processing
Toggle auto mode
https://gpt-cursor-runner.fly.dev/slack/commands

/theme
Manage Cursor theme settings
Manage theme
https://gpt-cursor-runner.fly.dev/slack/commands

/theme-status
Check current theme status
Theme status
https://gpt-cursor-runner.fly.dev/slack/commands

/theme-fix
Fix theme-related issues
Fix theme
https://gpt-cursor-runner.fly.dev/slack/commands

/patch-preview
Preview pending patches
Preview patch
https://gpt-cursor-runner.fly.dev/slack/commands

/approve-screenshot
Approve screenshot-based patches
Approve screenshot
https://gpt-cursor-runner.fly.dev/slack/commands

/revert-phase
Revert to previous phase
Revert phase
https://gpt-cursor-runner.fly.dev/slack/commands

/log-phase-status
Log current phase status
Log status
https://gpt-cursor-runner.fly.dev/slack/commands

/cursor-mode
Switch Cursor operation modes
Switch mode
https://gpt-cursor-runner.fly.dev/slack/commands

/whoami
Show current user and permissions
Show user info
https://gpt-cursor-runner.fly.dev/slack/commands

/retry-last-failed
Retry the last failed operation
Retry failed
https://gpt-cursor-runner.fly.dev/slack/commands

/lock-runner
Lock runner (prevent changes)
Lock runner
https://gpt-cursor-runner.fly.dev/slack/commands

/unlock-runner
Unlock runner (allow changes)
Unlock runner
https://gpt-cursor-runner.fly.dev/slack/commands

/alert-runner-crash
Send crash alert notification
Alert crash
https://gpt-cursor-runner.fly.dev/slack/commands
      
    - command: /read-secret
Fetch and display a secret from Vault or 1Password
/read-secret SECRET_NAME
https://gpt-cursor-runner.fly.dev/slack/commands

# README 
### Notes on Slack /slash Commands

Refinements {
    Rename the following /slash commands, {
        /status > /status-runner,
        /kill-runner > /kill,
        },
    Confim definitions, {
    Patch: I'm assuming cursor updates, summaries, replies, requests are considered patches. Patches are the thing we're broadly using to define messages on this two-way street between cursor and GPT. cursor is also passing 'patches' back to gpt (replys, staus, pauses to request proceed approval, give summaries), yes?
    Assumption: /slash input is acceptable to narrow or add additonal to any command. or are..
    Command Strings: acceptable? send a few inline commands in a row. ex. 
    },
    I need an action/command, {
    /manual-revise; input custom input/reply and send back to source (gpt or cursor) for another attempt after UNABRIDGED revision
    /manual-append input and append custom input/reply and pass-thru
    /interrupt pause runner or current operation > I can add text string for context or redirect > pass and resume
    },
    combine/replace redundant {
        /approve-screenshot, /continue-runner, /restart-runner, /resume-runner; with, {
        /proceed 
        passes through "proceed" to continue or restart with option to specify <as reply or passthru> with optional addition of 'nostop' (instuctional reply to continue silently without stopping until current is complete. (to keep cursor from stopping every 2 seconds-- silent operation until completion of patch)
            },
        /retry-last-failed, /restart-runner, /restart-runner-gpt, /restart-runner; with, {
        /again <gpt or cursor? (optional) with manual additional context>
            restarts or retrys last with optional manual input.
        }
    }
}
    
## FINAL COMMAND LIST (for now) : LIMITED BY SLACK 25 /slash MAX
/dashboard

/patch-pass

/patch-revert

/pause-runner

/restart-runner

/status-runner

/roadmap

/kill

/toggle-runner-auto

/patch-preview

/approve-screenshot

/revert-phase

/log-phase-status

/cursor-mode

/alert-runner-crash

/read-secret

/proceed

/again

/manual-return

/manual-append

/interrupt



