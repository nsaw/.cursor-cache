
#!/bin/bash

# Tunnel Watchdog: Ensures all tunnels stay alive via launchd

TUNNELS=("expo-dev" "mobile-dev" "runner-dev" "tm-runner-expo")
PLIST_DIR="$HOME/.launchd"
LOG_DIR="$HOME/gitsync/_backups/watchdog"
mkdir -p "$LOG_DIR"

for TUNNEL in "${TUNNELS[@]}"; do
    LABEL="com.thoughtmarks.$TUNNEL"
    PLIST="$PLIST_DIR/$LABEL.plist"

    if ! pgrep -f "$LABEL" > /dev/null; then
        echo "$(date) — Tunnel $TUNNEL is DOWN. Restarting..." >> "$LOG_DIR/$TUNNEL.log"
        launchctl unload "$PLIST"
        sleep 2
        launchctl load -w "$PLIST"
        echo "$(date) — Tunnel $TUNNEL restarted." >> "$LOG_DIR/$TUNNEL.log"
    else
        echo "$(date) — Tunnel $TUNNEL is healthy." >> "$LOG_DIR/$TUNNEL.log"
    fi
done
