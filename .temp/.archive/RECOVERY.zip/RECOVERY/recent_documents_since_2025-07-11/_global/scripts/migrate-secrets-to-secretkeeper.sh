#!/bin/bash

SOURCE_VAULT="SawyerSecrets"
TARGET_VAULT="SecretKeeper"

echo "🔁 Starting deduplicated migration from '$SOURCE_VAULT' → '$TARGET_VAULT'..."

# Ensure 1Password session is loaded
if [[ -z "$OP_SESSION_my" ]]; then
  echo "🔐 No 1Password session found. Attempting to sign in..."
  export OP_SESSION_my=$(op signin my.1password.com --raw)
fi

# Get all unique items by ID and title
op item list --vault "$SOURCE_VAULT" --format json | jq -c '.[]' | while read -r item; do
  ID=$(echo "$item" | jq -r '.id')
  TITLE=$(echo "$item" | jq -r '.title')

  # Skip if already migrated
  if op item get "$TITLE" --vault "$TARGET_VAULT" > /dev/null 2>&1; then
    echo "⚠️  Skipping '$TITLE' — already exists in target vault."
    continue
  fi

  echo "📦 Migrating '$TITLE' (ID: $ID)"
  ITEM_JSON=$(op item get "$ID" --vault "$SOURCE_VAULT" --format json)

  if echo "$ITEM_JSON" | op item create --vault "$TARGET_VAULT" --format json > /dev/null; then
    echo "✅ '$TITLE' migrated successfully."
  else
    echo "❌ Failed to migrate '$TITLE'"
  fi
done

echo "🎉 Vault migration complete."
