#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// Configuration
const ENV_FILE = path.join(process.env.HOME, 'gitSync', '_global', '.env');
const VAULT_ADDR = 'http://127.0.0.1:8200';
const VAULT_PATH = 'secret/data/sawyer-dev';
const VAULT_TOKEN_FILE = path.join(process.env.HOME, '.vault-token');

// CLI arguments
const argv = require('yargs/yargs')(process.argv.slice(2))
  .option('dry-run', {
    alias: 'd',
    type: 'boolean',
    description: 'Show what would be synced without actually syncing'
  })
  .option('force', {
    alias: 'f',
    type: 'boolean',
    description: 'Force update existing secrets'
  })
  .option('verbose', {
    alias: 'v',
    type: 'boolean',
    description: 'Verbose logging'
  })
  .help()
  .argv;

// Utility functions
function log(message, level = 'info') {
  const timestamp = new Date().toISOString();
  const prefix = level === 'error' ? '❌' : level === 'success' ? '✓' : level === 'skip' ? '–' : 'ℹ';
  console.log(`[${timestamp}] ${prefix} ${message}`);
}

function parseEnvFile(filePath) {
  if (!fs.existsSync(filePath)) {
    throw new Error(`Environment file not found: ${filePath}`);
  }
  
  const content = fs.readFileSync(filePath, 'utf8');
  const env = {};
  
  content.split('\n').forEach((line, index) => {
    line = line.trim();
    if (line && !line.startsWith('#')) {
      const match = line.match(/^([^=]+)=(.*)$/);
      if (match) {
        env[match[1]] = match[2];
      } else if (argv.verbose) {
        log(`Skipping malformed line ${index + 1}: ${line}`, 'skip');
      }
    }
  });
  
  return env;
}

function checkVaultConnection() {
  try {
    const token = fs.readFileSync(VAULT_TOKEN_FILE, 'utf8').trim();
    const result = execSync(`VAULT_ADDR="${VAULT_ADDR}" VAULT_TOKEN="${token}" vault status`, { 
      encoding: 'utf8',
      stdio: 'pipe'
    });
    // Accept any line with 'Sealed' and 'false' (robust to whitespace)
    if (/Sealed\s*:?.*false/.test(result)) {
      log('Vault connection successful', 'success');
      return token;
    } else {
      throw new Error('Vault is sealed or not running');
    }
  } catch (error) {
    log(`Vault connection failed: ${error.message}`, 'error');
    log('Make sure Vault is running with: ~/gitSync/_global/vault.sh', 'error');
    process.exit(1);
  }
}

function enableKVSecrets(token) {
  try {
    execSync(`VAULT_ADDR="${VAULT_ADDR}" VAULT_TOKEN="${token}" vault secrets enable -path=secret kv-v2`, {
      stdio: 'pipe'
    });
    log('KV v2 secrets engine enabled at /secret', 'success');
  } catch (error) {
    if (error.message.includes('already in use') || error.message.includes('already enabled')) {
      log('KV v2 secrets engine already enabled at /secret', 'skip');
      // Do not throw, just continue
    } else {
      log(`Failed to enable KV secrets: ${error.message}`, 'error');
      // Only throw for fatal errors
      throw error;
    }
  }
}

function syncSecretToVault(key, value, token) {
  const secretData = {
    data: {
      [key]: value
    }
  };
  
  const jsonData = JSON.stringify(secretData);
  
  try {
    if (argv['dry-run']) {
      log(`[DRY-RUN] Would sync: ${key}`, 'skip');
      return true;
    }
    
    execSync(`VAULT_ADDR="${VAULT_ADDR}" VAULT_TOKEN="${token}" vault kv put ${VAULT_PATH}/${key} data='${jsonData}'`, {
      stdio: 'pipe'
    });
    
    log(`Synced: ${key}`, 'success');
    return true;
  } catch (error) {
    log(`Failed to sync ${key}: ${error.message}`, 'error');
    return false;
  }
}

function bulkSyncToVault(env, token) {
  log(`Starting bulk sync of ${Object.keys(env).length} secrets to Vault...`, 'info');
  
  let successCount = 0;
  let failCount = 0;
  
  Object.entries(env).forEach(([key, value]) => {
    const success = syncSecretToVault(key, value, token);
    if (success) {
      successCount++;
    } else {
      failCount++;
    }
  });
  
  log(`Sync completed: ${successCount} successful, ${failCount} failed`, 'info');
  return { successCount, failCount };
}

function verifySecrets(token) {
  log('Verifying secrets in Vault...', 'info');
  
  try {
    const result = execSync(`VAULT_ADDR="${VAULT_ADDR}" VAULT_TOKEN="${token}" vault kv list ${VAULT_PATH}`, {
      encoding: 'utf8',
      stdio: 'pipe'
    });
    
    const keys = result.trim().split('\n').filter(line => line.trim());
    log(`Found ${keys.length} secrets in Vault`, 'success');
    
    if (argv.verbose) {
      keys.forEach(key => {
        try {
          const secret = execSync(`VAULT_ADDR="${VAULT_ADDR}" VAULT_TOKEN="${token}" vault kv get ${VAULT_PATH}/${key}`, {
            encoding: 'utf8',
            stdio: 'pipe'
          });
          log(`  ${key}: ${secret.includes('data') ? '✓' : '✗'}`, 'info');
        } catch (error) {
          log(`  ${key}: ✗ (error: ${error.message})`, 'error');
        }
      });
    }
    
    return keys.length;
  } catch (error) {
    log(`Failed to verify secrets: ${error.message}`, 'error');
    return 0;
  }
}

// Main execution
function main() {
  log('🔐 Vault Environment Sync Tool', 'info');
  log(`📁 Source: ${ENV_FILE}`, 'info');
  log(`🗄️  Target: ${VAULT_PATH}`, 'info');
  
  if (argv['dry-run']) {
    log('🔍 DRY RUN MODE - No changes will be made', 'info');
  }
  
  // Parse environment file
  log('📖 Reading environment file...', 'info');
  const env = parseEnvFile(ENV_FILE);
  log(`Found ${Object.keys(env).length} environment variables`, 'success');
  
  // Check Vault connection
  log('🔗 Checking Vault connection...', 'info');
  const token = checkVaultConnection();
  
  // Enable KV secrets engine
  log('⚙️  Setting up KV secrets engine...', 'info');
  enableKVSecrets(token);
  
  // Sync secrets to Vault
  log('🔄 Syncing secrets to Vault...', 'info');
  const { successCount, failCount } = bulkSyncToVault(env, token);
  
  // Verify the sync
  if (!argv['dry-run']) {
    const verifiedCount = verifySecrets(token);
    log(`✅ Verification complete: ${verifiedCount} secrets found in Vault`, 'success');
  }
  
  if (argv['dry-run']) {
    log('🔍 Dry run completed - no changes made', 'info');
  } else if (failCount === 0) {
    log('🎉 All secrets synced successfully!', 'success');
  } else {
    log(`⚠️  Sync completed with ${failCount} failures`, 'error');
  }
}

if (require.main === module) {
  main();
}

module.exports = { parseEnvFile, syncSecretToVault, verifySecrets }; 