#!/bin/bash

# Generate launchd plist files for Cloudflare tunnels
# Usage: ./generate_launchd.sh --target braun

TARGET=${2:-"braun"}
LAUNCHD_DIR="$HOME/.launchd"
CONFIG_DIR="$HOME/gitsync/_global/dev-tools/cloudflare"
LOG_DIR="$HOME/gitsync/_backups"

mkdir -p "$LAUNCHD_DIR"

# Function to generate plist for a tunnel
generate_plist() {
    local tunnel_name=$1
    local config_file=$2
    local plist_file="$LAUNCHD_DIR/com.thoughtmarks.$tunnel_name.plist"
    local log_file="$LOG_DIR/cloudflared_${tunnel_name}.log"
    
    cat > "$plist_file" << INNEREOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.thoughtmarks.$tunnel_name</string>
    <key>ProgramArguments</key>
    <array>
        <string>/usr/local/bin/cloudflared</string>
        <string>tunnel</string>
        <string>--config</string>
        <string>$config_file</string>
        <string>run</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>$log_file</string>
    <key>StandardErrorPath</key>
    <string>$log_file</string>
    <key>WorkingDirectory</key>
    <string>$HOME</string>
</dict>
</plist>
INNEREOF
    
    echo "Generated plist for $tunnel_name: $plist_file"
}

# Generate plists for all tunnels
generate_plist "expo" "$CONFIG_DIR/expo.yml"
generate_plist "mobile" "$CONFIG_DIR/mobile.yml"
generate_plist "runner" "$CONFIG_DIR/runner.yml"
generate_plist "tmrunner" "$CONFIG_DIR/tm-runner.yml"

echo "All launchd plist files generated in $LAUNCHD_DIR"
echo "To load services: launchctl load -w $LAUNCHD_DIR/*.plist"
