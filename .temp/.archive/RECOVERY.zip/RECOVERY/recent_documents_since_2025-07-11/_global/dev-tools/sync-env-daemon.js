#!/usr/bin/env node

/**
 * Secrets Sync Daemon
 * 
 * Watches ~/gitsync/_global/.env and syncs environment variables
 * to project-local .env files with CLI arguments and human-readable tracking.
 */

const fs = require('fs');
const path = require('path');
const chokidar = require('chokidar');
const yargs = require('yargs/yargs');
const { hideBin } = require('yargs/helpers');

// Configuration
const GLOBAL_ENV_PATH = path.resolve(process.env.HOME, 'gitsync/_global/.env');
const SECRETS_STORE_PATH = path.resolve(process.env.HOME, 'gitsync/_global/secrets.store.json');
const PROJECTS = [
  {
    name: 'tm-mobile-cursor',
    path: path.resolve(process.env.HOME, 'gitSync/tm-mobile-cursor/.env')
  },
  {
    name: 'gpt-cursor-runner', 
    path: path.resolve(process.env.HOME, 'gitSync/gpt-cursor-runner/.env')
  }
];

// CLI Arguments
const argv = yargs(hideBin(process.argv))
  .option('force', {
    type: 'boolean',
    default: false,
    description: 'Force override matching keys in target .env files'
  })
  .option('exclude', {
    type: 'string',
    description: 'Comma-separated list of environment variables to exclude from sync'
  })
  .option('sync', {
    type: 'boolean',
    default: false,
    description: 'Manually trigger sync once and exit'
  })
  .option('watch', {
    type: 'boolean',
    default: true,
    description: 'Watch for changes (default: true)'
  })
  .option('verbose', {
    type: 'boolean',
    default: false,
    description: 'Verbose logging'
  })
  .help()
  .argv;

// Utility functions
function log(message, type = 'info') {
  const timestamp = new Date().toISOString();
  const prefix = type === 'error' ? '❌' : type === 'success' ? '✓' : type === 'skip' ? '–' : 'ℹ️';
  console.log(`[${timestamp}] ${prefix} ${message}`);
}

function parseEnvFile(filePath) {
  if (!fs.existsSync(filePath)) {
    return {};
  }
  
  const content = fs.readFileSync(filePath, 'utf8');
  const env = {};
  
  content.split('\n').forEach(line => {
    line = line.trim();
    if (line && !line.startsWith('#')) {
      const match = line.match(/^([^=]+)=(.*)$/);
      if (match) {
        env[match[1]] = match[2];
      }
    }
  });
  
  return env;
}

function writeEnvFile(filePath, env) {
  const content = Object.entries(env)
    .map(([key, value]) => `${key}=${value}`)
    .join('\n') + '\n';
  
  fs.writeFileSync(filePath, content, 'utf8');
}

function loadSecretsStore() {
  if (!fs.existsSync(SECRETS_STORE_PATH)) {
    return {};
  }
  
  try {
    const content = fs.readFileSync(SECRETS_STORE_PATH, 'utf8');
    return JSON.parse(content);
  } catch (error) {
    log(`Error loading secrets store: ${error.message}`, 'error');
    return {};
  }
}

function saveSecretsStore(secrets) {
  try {
    const content = JSON.stringify(secrets, null, 2);
    fs.writeFileSync(SECRETS_STORE_PATH, content, 'utf8');
    log(`Secrets store updated: ${SECRETS_STORE_PATH}`);
  } catch (error) {
    log(`Error saving secrets store: ${error.message}`, 'error');
  }
}

function generateSecretsStoreFromEnv(env) {
  const secrets = {};
  
  Object.entries(env).forEach(([key, value]) => {
    secrets[key] = {
      value: value,
      description: `Auto-generated from .env on ${new Date().toISOString()}`,
      lastUpdated: new Date().toISOString()
    };
  });
  
  return secrets;
}

function updateSecretsStore(env) {
  const existingSecrets = loadSecretsStore();
  const newSecrets = generateSecretsStoreFromEnv(env);
  
  // Merge existing and new secrets, preserving descriptions
  const mergedSecrets = { ...existingSecrets };
  
  Object.entries(newSecrets).forEach(([key, secret]) => {
    if (!existingSecrets[key] || existingSecrets[key].value !== secret.value) {
      mergedSecrets[key] = secret;
    }
  });
  
  saveSecretsStore(mergedSecrets);
  return mergedSecrets;
}

function syncEnvToProjects(force = false, excludeKeys = []) {
  if (!fs.existsSync(GLOBAL_ENV_PATH)) {
    log(`Global .env not found: ${GLOBAL_ENV_PATH}`, 'error');
    return false;
  }
  
  const globalEnv = parseEnvFile(GLOBAL_ENV_PATH);
  const excludeSet = new Set(excludeKeys);
  
  // Update secrets store
  const secrets = updateSecretsStore(globalEnv);
  
  log(`Syncing ${Object.keys(globalEnv).length} environment variables to ${PROJECTS.length} projects`);
  
  PROJECTS.forEach(project => {
    try {
      const targetEnv = parseEnvFile(project.path);
      let changed = false;
      let synced = 0;
      let skipped = 0;
      
      Object.entries(globalEnv).forEach(([key, value]) => {
        if (excludeSet.has(key)) {
          if (argv.verbose) log(`Skipping excluded key: ${key}`, 'skip');
          skipped++;
          return;
        }
        
        if (!targetEnv[key] || force) {
          targetEnv[key] = value;
          changed = true;
          synced++;
          if (argv.verbose) log(`Synced ${key} to ${project.name}`, 'success');
        } else {
          if (argv.verbose) log(`Skipped ${key} (already exists in ${project.name})`, 'skip');
          skipped++;
        }
      });
      
      if (changed) {
        writeEnvFile(project.path, targetEnv);
        log(`[✓] Updated ${project.name}: ${synced} synced, ${skipped} skipped`);
      } else {
        log(`[–] No changes for ${project.name}: ${synced} synced, ${skipped} skipped`);
      }
      
    } catch (error) {
      log(`Error syncing to ${project.name}: ${error.message}`, 'error');
    }
  });
  
  return true;
}

function startWatcher() {
  log(`Starting watcher for: ${GLOBAL_ENV_PATH}`);
  
  const watcher = chokidar.watch(GLOBAL_ENV_PATH, {
    persistent: true,
    ignoreInitial: false,
    awaitWriteFinish: {
      stabilityThreshold: 1000,
      pollInterval: 100
    }
  });
  
  watcher.on('add', (path) => {
    log(`File added: ${path}`);
    syncEnvToProjects(argv.force, argv.exclude ? argv.exclude.split(',') : []);
  });
  
  watcher.on('change', (path) => {
    log(`File changed: ${path}`);
    syncEnvToProjects(argv.force, argv.exclude ? argv.exclude.split(',') : []);
  });
  
  watcher.on('error', (error) => {
    log(`Watcher error: ${error.message}`, 'error');
  });
  
  // Handle graceful shutdown
  process.on('SIGINT', () => {
    log('Shutting down watcher...');
    watcher.close();
    process.exit(0);
  });
  
  process.on('SIGTERM', () => {
    log('Shutting down watcher...');
    watcher.close();
    process.exit(0);
  });
  
  return watcher;
}

// Main execution
function main() {
  log('Secrets Sync Daemon starting...');
  
  if (argv.sync) {
    log('Manual sync triggered');
    const success = syncEnvToProjects(argv.force, argv.exclude ? argv.exclude.split(',') : []);
    process.exit(success ? 0 : 1);
  }
  
  if (argv.watch) {
    startWatcher();
  } else {
    log('Watch mode disabled, exiting');
    process.exit(0);
  }
}

// Run if called directly
if (require.main === module) {
  main();
}

module.exports = {
  syncEnvToProjects,
  loadSecretsStore,
  saveSecretsStore,
  updateSecretsStore
}; 