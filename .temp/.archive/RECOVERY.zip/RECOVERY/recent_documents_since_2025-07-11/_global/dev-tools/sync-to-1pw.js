#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const ENV_FILE = path.join(process.env.HOME, 'gitSync', '_global', '.env');
const VAULT_NAME = 'SawyerSecrets';

const argv = require('yargs/yargs')(process.argv.slice(2))
  .option('force', {
    alias: 'f',
    type: 'boolean',
    description: 'Force update existing items'
  })
  .option('dry', {
    alias: 'd',
    type: 'boolean',
    description: 'Dry run (show what would be done)'
  })
  .option('verbose', {
    alias: 'v',
    type: 'boolean',
    description: 'Verbose logging'
  })
  .help()
  .argv;

function log(msg, level = 'info') {
  const prefix = level === 'error' ? '❌' : level === 'success' ? '✓' : level === 'skip' ? '–' : 'ℹ';
  console.log(`[${prefix}] ${msg}`);
}

function parseEnvFile(filePath) {
  if (!fs.existsSync(filePath)) throw new Error(`.env not found: ${filePath}`);
  const content = fs.readFileSync(filePath, 'utf8');
  const env = {};
  content.split('\n').forEach((line, i) => {
    line = line.trim();
    if (line && !line.startsWith('#')) {
      const match = line.match(/^([^=]+)=(.*)$/);
      if (match) env[match[1]] = match[2];
      else if (argv.verbose) log(`Skipping malformed line ${i + 1}: ${line}`, 'skip');
    }
  });
  return env;
}

function itemExists(key) {
  try {
    execSync(`op item get ${key} --vault "${VAULT_NAME}" --fields label`, { stdio: 'pipe' });
    return true;
  } catch {
    return false;
  }
}

function createOrUpdateItem(key, value) {
  if (argv.dry) {
    log(`[DRY] Would create/update: ${key}`);
    return true;
  }
  if (itemExists(key)) {
    if (!argv.force) {
      log(`Item exists, skipping: ${key}`, 'skip');
      return false;
    }
    // Update
    try {
      execSync(`op item edit ${key} password='${value.replace(/'/g, "'\''")}' --vault "${VAULT_NAME}"`, { stdio: 'pipe' });
      log(`Updated: ${key}`, 'success');
      return true;
    } catch (e) {
      log(`Failed to update ${key}: ${e.message}`, 'error');
      return false;
    }
  } else {
    // Create
    try {
      execSync(`op item create --category=PASSWORD --title='${key}' password='${value.replace(/'/g, "'\''")}' --vault "${VAULT_NAME}" --tags=env-sync`, { stdio: 'pipe' });
      log(`Created: ${key}`, 'success');
      return true;
    } catch (e) {
      log(`Failed to create ${key}: ${e.message}`, 'error');
      return false;
    }
  }
}

function main() {
  log('🔑 1Password .env Bulk Import');
  const env = parseEnvFile(ENV_FILE);
  log(`Found ${Object.keys(env).length} variables in .env`);
  let created = 0, updated = 0, skipped = 0, failed = 0;
  for (const [key, value] of Object.entries(env)) {
    if (itemExists(key)) {
      if (argv.force) {
        if (createOrUpdateItem(key, value)) updated++;
        else failed++;
      } else {
        log(`Item exists, skipping: ${key}`, 'skip');
        skipped++;
      }
    } else {
      if (createOrUpdateItem(key, value)) created++;
      else failed++;
    }
  }
  log(`Done. Created: ${created}, Updated: ${updated}, Skipped: ${skipped}, Failed: ${failed}`);
}

if (require.main === module) main(); 