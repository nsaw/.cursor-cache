# Secret Management Workflows

This document covers the dual secret management setup using HashiCorp Vault and 1Password CLI for development and production environments.

## 🔐 HashiCorp Vault (Local Development)

### Quick Start
```bash
# Start Vault in dev mode
cd ~/gitSync/_global && ./vault.sh

# In another terminal, sync .env to Vault
cd ~/gitSync/dev-tools && node vault-sync-env.js
```

### Vault Commands
```bash
# Check Vault status
VAULT_ADDR="http://127.0.0.1:8200" VAULT_TOKEN="dev-token-sawyer" vault status

# List secrets
VAULT_ADDR="http://127.0.0.1:8200" VAULT_TOKEN="dev-token-sawyer" vault kv list secret/data/sawyer-dev

# Get a specific secret
VAULT_ADDR="http://127.0.0.1:8200" VAULT_TOKEN="dev-token-sawyer" vault kv get secret/data/sawyer-dev/SLACK_BOT_TOKEN

# Sync with options
node vault-sync-env.js --dry-run --verbose  # Preview changes
node vault-sync-env.js --force --verbose    # Force update all
```

### Vault Files
- **Startup Script**: `~/gitSync/_global/vault.sh`
- **Sync Script**: `~/gitSync/dev-tools/vault-sync-env.js`
- **Token File**: `~/.vault-token`
- **Vault Address**: `http://127.0.0.1:8200`
- **Secrets Path**: `secret/data/sawyer-dev`

---

## 🔑 1Password CLI (Production/Team)

### Quick Start
```bash
# Check authentication
op account list

# Sync .env to 1Password
cd ~/gitSync/dev-tools && ./sync-to-1pw.js --force
```

### 1Password Commands
```bash
# List items in vault
op item list --vault SawyerSecrets

# Get a specific secret
op item get SLACK_BOT_TOKEN --vault SawyerSecrets --fields password

# Get by UUID (if name doesn't work)
op item get <UUID> --reveal --vault SawyerSecrets --fields password

# Sync with options
./sync-to-1pw.js --dry --verbose     # Preview changes
./sync-to-1pw.js --force --verbose   # Force update all
```

### 1Password Files
- **Sync Script**: `~/gitSync/dev-tools/sync-to-1pw.js`
- **Vault Name**: `SawyerSecrets`
- **Account**: `designsawyer@gmail.com`

---

## 🔄 Environment Sync Daemon

The environment sync daemon automatically keeps project `.env` files in sync:

```bash
# Manual sync
cd ~/gitSync/dev-tools && node sync-env-daemon.js --sync

# Watch mode (auto-sync on changes)
node sync-env-daemon.js --watch

# Force override existing variables
node sync-env-daemon.js --sync --force

# Exclude specific variables
node sync-env-daemon.js --sync --exclude=SLACK_BOT_TOKEN,OPENAI_API_KEY
```

### Daemon Files
- **Script**: `~/gitSync/dev-tools/sync-env-daemon.js`
- **LaunchDaemon**: `~/Library/LaunchAgents/dev.sawyer.envsync.plist`
- **Logs**: `~/gitSync/dev-tools/envsync.log`

---

## 🚀 Runtime Injection (Optional)

### 1Password Runtime Injection
Create a `.op.env` template file:
```bash
# Create template with placeholders
cat > .op.env << EOF
SLACK_BOT_TOKEN=\${SLACK_BOT_TOKEN}
OPENAI_API_KEY=\${OPENAI_API_KEY}
DATABASE_URL=\${DATABASE_URL}
EOF

# Inject at runtime
op inject -i .op.env -o .env
```

### Vault Runtime Injection
```bash
# Create a script to fetch from Vault
cat > vault-to-env.sh << 'EOF'
#!/bin/bash
VAULT_ADDR="http://127.0.0.1:8200"
VAULT_TOKEN="dev-token-sawyer"

# Fetch secrets and write to .env
vault kv get secret/data/sawyer-dev/SLACK_BOT_TOKEN --format=json | jq -r '.data.data.SLACK_BOT_TOKEN' > .env
EOF
```

---

## 📋 Workflow Examples

### Development Workflow
```bash
# 1. Start Vault
cd ~/gitSync/_global && ./vault.sh &

# 2. Sync secrets to Vault
cd ~/gitSync/dev-tools && node vault-sync-env.js

# 3. Use secrets in your app
export SLACK_BOT_TOKEN=$(VAULT_ADDR="http://127.0.0.1:8200" VAULT_TOKEN="dev-token-sawyer" vault kv get secret/data/sawyer-dev/SLACK_BOT_TOKEN --format=json | jq -r '.data.data.SLACK_BOT_TOKEN')
```

### Production Workflow
```bash
# 1. Sync secrets to 1Password
cd ~/gitSync/dev-tools && ./sync-to-1pw.js --force

# 2. Use secrets in your app
export SLACK_BOT_TOKEN=$(op item get SLACK_BOT_TOKEN --vault SawyerSecrets --fields password)

# Or inject at runtime
op inject -i .op.env -o .env
```

### Team Collaboration
```bash
# Share secrets via 1Password
op item share SLACK_BOT_TOKEN --vault SawyerSecrets --emails=teammate@example.com

# Export vault for backup
op vault export SawyerSecrets --format=json > sawyer-secrets-backup.json
```

---

## 🔧 Troubleshooting

### Vault Issues
```bash
# Check if Vault is running
ps aux | grep vault

# Restart Vault
pkill vault && cd ~/gitSync/_global && ./vault.sh &

# Check token
cat ~/.vault-token

# Test connection
VAULT_ADDR="http://127.0.0.1:8200" VAULT_TOKEN="dev-token-sawyer" vault status
```

### 1Password Issues
```bash
# Check authentication
op account list

# Re-authenticate if needed
op signin

# Check vault exists
op vault list | grep SawyerSecrets

# Test retrieval
op item get SLACK_BOT_TOKEN --vault SawyerSecrets --fields password
```

### Sync Issues
```bash
# Check daemon status
launchctl list | grep envsync

# Restart daemon
launchctl unload ~/Library/LaunchAgents/dev.sawyer.envsync.plist
launchctl load ~/Library/LaunchAgents/dev.sawyer.envsync.plist

# Check logs
tail -f ~/gitSync/dev-tools/envsync.log
```

---

## 📚 Script Reference

### vault-sync-env.js
```bash
node vault-sync-env.js [options]

Options:
  --dry-run, -d    Show what would be synced without actually syncing
  --force, -f      Force update existing secrets
  --verbose, -v    Verbose logging
  --help           Show help
```

### sync-to-1pw.js
```bash
./sync-to-1pw.js [options]

Options:
  --force, -f      Force update existing items
  --dry, -d        Dry run (show what would be done)
  --verbose, -v    Verbose logging
  --help           Show help
```

### sync-env-daemon.js
```bash
node sync-env-daemon.js [options]

Options:
  --sync, -s       Manual sync once and exit
  --force, -f      Force override matching keys
  --exclude, -e    Comma-separated list of variables to exclude
  --watch, -w      Watch for changes (default: true)
  --verbose, -v    Verbose logging
  --help           Show help
```

---

## 🔒 Security Notes

- **Vault**: Development mode only - not for production
- **1Password**: Use for production and team sharing
- **Tokens**: Keep `~/.vault-token` secure
- **Logs**: Check `envsync.log` for sensitive data
- **Backup**: Regularly export 1Password vault
- **Rotation**: Update secrets regularly in both systems 