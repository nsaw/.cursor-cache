#!/bin/bash
# Fetch all secrets from Vault and write to .env
set -e
VAULT_ADDR="http://127.0.0.1:8200"
VAULT_TOKEN="dev-token-sawyer"
VAULT_PATH="secret/data/sawyer-dev"

# Fetch all keys (list)
KEYS=$(vault kv get -format=json $VAULT_PATH | jq -r '.data.data | keys[]')

# Write each key=value to .env
: > .env
for key in $KEYS; do
  value=$(vault kv get -format=json $VAULT_PATH | jq -r ".data.data.$key")
  echo "$key=$value" >> .env
done

echo "[✓] .env written from Vault ($VAULT_PATH)" 