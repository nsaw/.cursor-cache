# GPT ↔ Runner ↔ Cursor Routing and Enhancements Overview

## 🔁 Communication Flow

| Actor | Action | Routed By | Final Receiver |
|-------|--------|-----------|----------------|
| **User (Slack)** | Slash Command or Button | Slack API → Runner | GPT or Cursor |
| **GPT** | Patch/Reply | Runner (dispatch) | Cursor |
| **Cursor** | Patch/Status/Log | Runner (relay) | GPT |
| **User** | `/manual-revise`, `/interrupt`, etc. | Slack → Runner | GPT ↔ Cursor |
| **Slack App** | Button click / Reaction | Slack → Runner | GPT or Cursor |

---

## ✅ Enabled Enhancements

### Slack → Runner
- `/gpt-broadcast` → Multi-channel/DM delivery
- `/interrupt`, `/manual-append`, `/manual-revise` support long inputs
- `/proceed nostop` enables Cursor auto-run without stopping
- App Home includes Launch + Dashboard shortcuts
- Reactions supported:
  - ✅ Approve patch
  - 🔁 Retry
  - 🛑 Halt + notify GPT

---

### GPT → Slack
- GPT dispatches:
  - Patch summaries
  - Diagnostic + screenshots
  - Stack traces
  - Phase completion alerts
- Auto-threading enabled for all Slack messages
- Button-based actions: `Approve`, `Revert`, `Help`, `Dashboard`
- GPT functions:
  - `contextualPatch()`
  - `summarizePhase()`
  - `reportCrash()`
  - `promptForApproval()`

---

### GPT ↔ Cursor (via Runner)
- All GPT handoffs valid for Cursor processing
- `.cursor-instruction.json` sent via Slack routed through runner
- `/troubleshoot` auto-generates patch, runs fix, pauses for GPT review (if `oversight` toggled)

---

## 🤖 Usage Example in Slack

> _Plain Language OK!_  
> You can say things like:
> 
> > "Hey GPT, pass that `roadmap.md` over to Cursor when you're done.  
> > Cursor, build a to-do list when you receive that while GPT works on the hybrid blocks.  
> > Let GPT know when you're ready for the next phase of instruction blocks."

GPT and Cursor will respond accordingly and route all updates via the runner.
