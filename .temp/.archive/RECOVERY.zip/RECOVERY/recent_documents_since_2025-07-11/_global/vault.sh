#!/bin/bash

# Vault Development Server Startup Script
# This script starts Vault in development mode and configures the environment

set -e

echo "🔐 Starting HashiCorp Vault in development mode..."

# Set Vault environment variables
export VAULT_ADDR='http://127.0.0.1:8200'
export VAULT_DEV_ROOT_TOKEN_ID='dev-token-sawyer'

# Create token file for easy access
echo "$VAULT_DEV_ROOT_TOKEN_ID" > ~/.vault-token
chmod 600 ~/.vault-token

echo "📍 Vault will be available at: $VAULT_ADDR"
echo "🔑 Root token: $VAULT_DEV_ROOT_TOKEN_ID"
echo "💾 Token saved to: ~/.vault-token"
echo ""
echo "🚀 Starting Vault server..."

# Start Vault in development mode
vault server -dev \
  -dev-root-token-id="$VAULT_DEV_ROOT_TOKEN_ID" \
  -dev-listen-address="127.0.0.1:8200"

# Note: This script will block until Vault is stopped
# To stop Vault, press Ctrl+C 