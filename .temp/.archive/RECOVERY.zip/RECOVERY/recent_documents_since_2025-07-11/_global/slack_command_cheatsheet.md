# GPT-CURSOR RUNNER: SLACK COMMAND CHEATSHEET
_Please pin this to `#runner-control` or DM it to yourself using `/pin`_

---

## Cursor Slack Commands Cheat Sheet

### STATUS + INFO
`/status-runner` → Full system status + memory + patch stats  
`/dashboard` → Open patch dashboard  
`/whoami` → Your identity + access level  

### RUNNER CONTROLS
`/toggle-runner-auto` → Toggle auto/manual mode  
`/pause-runner` / `/proceed` → Pause or continue flow  
`/restart-runner` → Restart full GPT+Cursor loop  

### PATCH WORKFLOW
`/patch-pass` → Approve current patch  
`/patch-revert` → Revert latest patch  
`/patch-preview` → View pending patch before applying  
`/revert-phase` → Undo last full phase  
`/again` → Retry failed GPT or Cursor step  

### MANUAL INTERVENTION
`/manual-revise` → Send patch back to Cursor for revision  
`/manual-append` → Append your input + forward  
`/interrupt` → Pause and redirect flow manually  
`/send-with` → Request logs/screenshot/context  

### TROUBLESHOOTING
`/troubleshoot` → GPT auto-generates and applies diagnostic patch  
`/troubleshoot-oversight` → Auto-runs patch, pauses for human approval after  

### MODES + PHASES
`/cursor-mode` → Current run mode (auto/manual)  
`/log-phase-status` → Active phase + patch log  
`/roadmap` → Show roadmap milestones  

### EMERGENCY OPS
`/kill` → Emergency kill (hard stop)  
`/alert-runner-crash` → Report silent or unlogged crash  

### SECRETS MGMT
`/read-secret [KEY]` → Read stored env/secret  

---

**LINKS:**  
**Dashboard:** [`/dashboard`](https://dashboard.thoughtmarks.app)  
**Source:** [`/gpt-cursor-runner`](https://github.com/nsaw/gpt-cursor-runner)
