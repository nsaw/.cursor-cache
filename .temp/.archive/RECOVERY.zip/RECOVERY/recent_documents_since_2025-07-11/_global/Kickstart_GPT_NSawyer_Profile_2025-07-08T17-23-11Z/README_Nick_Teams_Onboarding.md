
# Nick Sawyer – GPT Teams Onboarding

## What This Package Contains

- Full Markdown profile: Nick's creative, technical, and behavioral blueprint
- JSON export: Structured for use in automated team environments
- Reference Blocks: Prebuilt Cursor-compatible setup
- Integration scripts: Scaffold for loading profile into a new workspace

## How to Use

1. Load the JSON profile into the new GPT Teams or custom GPT instance.
2. Use the markdown file for onboarding team members or assistants.
3. Drop the reference blocks into `/preferences/` or equivalent agent folder.
4. Run the setup script to auto-load memory into cursor/GPT hybrid environments.
