# Changelog: v1.3.2 Functional Base

## Added
- Deep link handler
- Siri donation logic
- Sign-in/sign-up forms
- Onboarding modal with animation
- Premium gating wrapper
- Role-based UI checks

## Changed
- Navigation stack separated by auth state

