# INDEX — UI Refactor Tasks (v1.4.0)

- [9] 9_v1.4.0_ui-refactor-preflight.cursor-instruction.json — Begin refactor
- [10] 10_v1.4.0_glass-morphism-ui-enforcer.cursor-instruction.json — Future overlay
