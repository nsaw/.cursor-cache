import React from 'react';
import { View, ViewProps, AccessibilityRole, Text } from 'react-native';

interface AutoRoleViewProps extends Omit<ViewProps, 'accessibilityRole' | 'role'> {
  role?: string;
  accessibilityRole?: AccessibilityRole;
  accessibilityLabel?: string;
  accessible?: boolean;
}

export const AutoRoleView: React.FC<AutoRoleViewProps> = ({
  role: _role, // Unused but kept for future role-based styling
  accessibilityRole,
  accessibilityLabel,
  accessible = true,
  style,
  children,
  ...props
}) => {
  return (
    <View><Text>{children}</Text></View>
  );
}; 