import { Text ,
  View,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import React from 'react';
import { Ionicons } from '@expo/vector-icons';

import { useTheme } from '../../../theme/ThemeProvider';
import { Button } from '../../../components/ui/Button';
import { Card, CardHeader, CardContent } from '../../../components/ui/Card';
import { useAuth } from '../../auth/hooks/useAuth';
import { AutoRoleView } from '../../../components/ui/AutoRoleView';

export const AdminDashboardScreen: React.FC = ({ navigation }: any) => {
  const { user } = useAuth();
  const { tokens: designTokens } = useTheme();

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: designTokens.colors.background ?? '#0D0D0F',
    },
    scrollView: {
      flex: 1,
    },
    header: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: designTokens.spacing.lg,
      borderBottomWidth: 1,
      borderBottomColor: designTokens.colors.border ?? '#000',
    },
    backButton: {
      padding: designTokens.spacing.sm,
    },
    title: {
      fontSize: designTokens.typography.fontSize.heading,
      fontWeight: '700',
      color: designTokens.colors.text ?? '#000',
      fontFamily: designTokens.typography.fontFamily.heading,
    },
    headerRight: {
      width: 48,
    },
    accessDenied: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      padding: designTokens.spacing.xl,
    },
    accessDeniedTitle: {
      fontSize: designTokens.typography.fontSize.heading,
      fontWeight: '700',
      color: designTokens.colors.danger ?? '#FF3B30',
      marginTop: designTokens.spacing.md,
      fontFamily: designTokens.typography.fontFamily.heading,
    },
    accessDeniedText: {
      fontSize: designTokens.typography.fontSize.sm,
      color: designTokens.colors.textSecondary ?? '#666',
      textAlign: 'center',
      marginTop: designTokens.spacing.sm,
      fontFamily: designTokens.typography.fontFamily.body,
    },
    adminInfoCard: {
      margin: designTokens.spacing.lg,
    },
    adminInfoTitle: {
      fontSize: designTokens.typography.fontSize.xl,
      fontWeight: '600',
      color: designTokens.colors.text ?? '#000',
      fontFamily: designTokens.typography.fontFamily.heading,
    },
    adminInfoText: {
      fontSize: designTokens.typography.fontSize.sm,
      color: designTokens.colors.textSecondary ?? '#666',
      fontFamily: designTokens.typography.fontFamily.body,
    },
    section: {
      margin: designTokens.spacing.lg,
    },
    sectionTitle: {
      fontSize: designTokens.typography.fontSize.xl,
      fontWeight: '600',
      color: designTokens.colors.text ?? '#000',
      fontFamily: designTokens.typography.fontFamily.heading,
    },
    buttonGrid: {
      gap: designTokens.spacing.md,
    },
    adminButton: {
      justifyContent: 'flex-start',
    },
  });

  const getIconColor = (type: 'danger' | 'accent' | 'background' | 'text') => {
    switch (type) {
      case 'danger':
        return designTokens.colors.danger ?? '#FF3B30';
      case 'accent':
        return designTokens.colors.accent ?? '#000';
      case 'background':
        return designTokens.colors.background ?? '#0D0D0F';
      case 'text':
        return designTokens.colors.text ?? '#000';
      default:
        return '#000';
    }
  };

  // Check if user is admin (you can customize this logic)
  const isAdmin = user?.email?.includes('admin') || user?.isAdmin || false;

  if (!isAdmin) {
    return (
      <ScrollView style={styles.container}>
        <ScrollView style={styles.accessDenied}>
          <Ionicons name="lock-closed" size={48} color={getIconColor('danger')} />
          <Text style={styles.accessDeniedTitle}>Access Denied</Text>
          <Text style={styles.accessDeniedText}>
            This area is restricted to administrators only.
          </Text>
        </ScrollView>
      </ScrollView>
    );
  }

  const handleDesignSystemDemo = () => {
    navigation.navigate('DesignSystemDemo');
  };

  const handleDatabaseReset = () => {
    Alert.alert(
      'Reset Database',
      'This will reset all data to demo state. This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Reset',
          style: 'destructive',
          onPress: () => {
            // Implement database reset logic here
            Alert.alert('Success', 'Database has been reset to demo state.');
          },
        },
      ]
    );
  };

  const handleExportData = () => {
    Alert.alert('Export Data', 'Data export functionality coming soon.');
  };

  const handleImportData = () => {
    Alert.alert('Import Data', 'Data import functionality coming soon.');
  };

  return (
    <ScrollView style={styles.container}>
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <ScrollView style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
          accessibilityRole="button"
          accessible={true}
          accessibilityLabel="Go back"
        >
          <Ionicons name="arrow-back" size={24} color={getIconColor('text')} />
        </TouchableOpacity>
          <Text style={styles.title}>Admin Dashboard</Text>
          <ScrollView style={styles.headerRight} />
        </ScrollView>

        {/* Admin Info */}
        <Card variant="elevated" style={styles.adminInfoCard}>
          <CardHeader>
            <Text style={styles.adminInfoTitle}>Administrator Access</Text>
          </CardHeader>
          <CardContent>
            <Text style={styles.adminInfoText}>
              Welcome, {user?.email}. You have full administrative access to the system.
            </Text>
          </CardContent>
        </Card>

        {/* Development Tools */}
        <Card variant="elevated" style={styles.section}>
          <CardHeader>
            <Text style={styles.sectionTitle}>Development Tools</Text>
          </CardHeader>
          <CardContent>
            <ScrollView style={styles.buttonGrid}>
              <Button
                variant="outline"
                onPress={handleDesignSystemDemo}
                leftIcon={<Ionicons name="color-palette-outline" size={16} color={getIconColor('accent')} />}
                style={styles.adminButton}
              ><Text>Design System Demo</Text></Button>

              <Button
                variant="outline"
                onPress={handleDatabaseReset}
                leftIcon={<Ionicons name="refresh-outline" size={16} color={getIconColor('danger')} />}
                style={styles.adminButton}
              ><Text>Reset Database</Text></Button>

              <Button
                variant="outline"
                onPress={handleExportData}
                leftIcon={<Ionicons name="download-outline" size={16} color={getIconColor('accent')} />}
                style={styles.adminButton}
              ><Text>Export Data</Text></Button>

              <Button
                variant="outline"
                onPress={handleImportData}
                leftIcon={<Ionicons name="cloud-upload-outline" size={16} color={getIconColor('accent')} />}
                style={styles.adminButton}
              ><Text>Import Data</Text></Button>
            </ScrollView>
          </CardContent>
        </Card>
      </ScrollView>
    </ScrollView>
  );
}; 