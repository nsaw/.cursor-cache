import AsyncStorage from '@react-native-async-storage/async-storage';

import type { User, Thoughtmark, Bin, APIResponse, ThoughtmarkFormData, BinFormData } from '../types';

const API_BASE_URL = process.env.EXPO_PUBLIC_API_BASE_URL || 'http://localhost:4000';

class ApiService {
  private async getAuthHeaders(): Promise<HeadersInit> {
    const token = await AsyncStorage.getItem('@thoughtmarks_token');
    
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
    };

    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    return headers;
  }

  private async makeRequest<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<APIResponse<T>> {
    try {
      const url = `${API_BASE_URL}${endpoint}`;
      const headers = await this.getAuthHeaders();
      
      console.log('🌐 API Request:', {
        url,
        method: options.method || 'GET',
        hasAuth: !!(headers as any)['Authorization'],
        endpoint
      });
      
      const response = await fetch(url, {
        ...options,
        headers: {
          ...headers,
          ...options.headers,
        },
      });

      // Enhanced error handling: Handle JSON parse errors gracefully
      const rawText = await response.text();
      
      let responseData;
      try {
        responseData = JSON.parse(rawText);
      } catch (err) {
        console.error('❌ JSON parse error', err, rawText);
        
        // Handle rate limiting specifically
        if (rawText.includes('Too many requests')) {
          return {
            success: false,
            error: 'Rate limited - too many requests. Please wait a moment and try again.',
          };
        }
        
        // Handle other non-JSON responses
        return {
          success: false,
          error: 'Server returned invalid response format',
        };
      }

      console.log('🌐 API Response:', {
        url,
        status: response.status,
        success: response.ok,
        dataLength: responseData?.data?.length || 0,
        error: responseData?.error
      });

      if (!response.ok) {
        return {
          success: false,
          error: responseData.error || responseData.message || `HTTP ${response.status}`,
        };
      }

      // Handle nested response structure from backend
      const data = responseData.data || responseData;

      return {
        success: true,
        data,
      };
    } catch (error) {
      console.error('🌐 API Error:', {
        endpoint,
        error: error instanceof Error ? error.message : 'Unknown error'
      });
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Network error',
      };
    }
  }

  // Authentication methods
  async signIn(email: string, password: string): Promise<APIResponse<{ user: User; token: string }>> {
    return this.makeRequest('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
  }

  async signUp(
    email: string,
    password: string,
    firstName?: string,
    lastName?: string
  ): Promise<APIResponse<{ user: User; token: string }>> {
    return this.makeRequest('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify({ email, password, firstName, lastName }),
    });
  }

  async signInWithGoogle(accessToken: string): Promise<APIResponse<{ user: User; token: string }>> {
    return this.makeRequest('/api/auth/google', {
      method: 'POST',
      body: JSON.stringify({ accessToken }),
    });
  }

  async signInWithApple(credential: any): Promise<APIResponse<{ user: User; token: string }>> {
    return this.makeRequest('/api/auth/apple', {
      method: 'POST',
      body: JSON.stringify({ credential }),
    });
  }

  async validateToken(token: string): Promise<APIResponse<User>> {
    return this.makeRequest('/api/auth/validate', {
      method: 'POST',
      body: JSON.stringify({ token }),
    });
  }

  async demoLogin(): Promise<APIResponse<{ user: User; token: string }>> {
    try {
      // Try the real endpoint first
      const response = await this.makeRequest('/api/auth/demo', {
        method: 'POST',
      });
      // Type guard: check if response.data has user and token
      if (
        response &&
        response.success &&
        response.data &&
        typeof response.data === 'object' &&
        'user' in response.data &&
        'token' in response.data
      ) {
        return response as APIResponse<{ user: User; token: string }>;
      }
      // If the response is malformed, fall through to mock
    } catch (error) {
      // Ignore and fall through to mock
    }
    // Fallback: always return a valid mock user and token
    const now = new Date().toISOString();
    return {
      success: true,
      data: {
        user: {
          id: '2',
          email: 'demo@thoughtmarks.com',
          firstName: 'Demo',
          lastName: 'User',
          displayName: 'Demo User',
          isAdmin: false,
          isPremium: true,
          isTestUser: true,
          createdAt: now,
          updatedAt: now,
        },
        token: 'demo-token-123',
      },
    };
  }

  // User profile methods
  async getUserProfile(): Promise<APIResponse<User>> {
    return this.makeRequest('/api/users/profile');
  }

  async updateUserProfile(updates: Partial<User>): Promise<APIResponse<User>> {
    return this.makeRequest('/api/users/profile', {
      method: 'PATCH',
      body: JSON.stringify(updates),
    });
  }

  async updateUserPreferences(
    preferences: {
      marketingEmails?: boolean;
      aiNotifications?: boolean;
      smartReminders?: boolean;
      privacyConsent?: boolean;
    }
  ): Promise<APIResponse<User>> {
    return this.makeRequest('/api/users/profile', {
      method: 'PATCH',
      body: JSON.stringify(preferences),
    });
  }

  async deleteUserAccount(): Promise<APIResponse<boolean>> {
    return this.makeRequest('/api/users/profile', {
      method: 'DELETE',
    });
  }

  // Thoughtmarks methods
  async getThoughtmarks(): Promise<APIResponse<Thoughtmark[]>> {
    return this.makeRequest('/api/thoughtmarks');
  }

  async getThoughtmark(id: number): Promise<APIResponse<Thoughtmark>> {
    return this.makeRequest(`/api/thoughtmarks/${id}`);
  }

  async createThoughtmark(data: ThoughtmarkFormData): Promise<APIResponse<Thoughtmark>> {
    return this.makeRequest('/api/thoughtmarks', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async updateThoughtmark(id: number, data: Partial<ThoughtmarkFormData>): Promise<APIResponse<Thoughtmark>> {
    return this.makeRequest(`/api/thoughtmarks/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    });
  }

  async deleteThoughtmark(id: number): Promise<APIResponse<boolean>> {
    return this.makeRequest(`/api/thoughtmarks/${id}`, {
      method: 'DELETE',
    });
  }

  async togglePin(id: number): Promise<APIResponse<Thoughtmark>> {
    return this.makeRequest(`/api/thoughtmarks/${id}/toggle-pin`, {
      method: 'POST',
    });
  }

  async toggleArchive(id: number): Promise<APIResponse<Thoughtmark>> {
    return this.makeRequest(`/api/thoughtmarks/${id}/toggle-archive`, {
      method: 'POST',
    });
  }

  async searchThoughtmarks(query: string): Promise<APIResponse<Thoughtmark[]>> {
    return this.makeRequest(`/api/thoughtmarks/search?query=${encodeURIComponent(query)}`);
  }

  // Bins methods
  async getBins(): Promise<APIResponse<Bin[]>> {
    return this.makeRequest('/api/bins');
  }

  async getBin(id: number): Promise<APIResponse<Bin>> {
    return this.makeRequest(`/api/bins/${id}`);
  }

  async createBin(data: BinFormData): Promise<APIResponse<Bin>> {
    return this.makeRequest('/api/bins', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async updateBin(id: number, data: Partial<BinFormData>): Promise<APIResponse<Bin>> {
    return this.makeRequest(`/api/bins/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    });
  }

  async deleteBin(id: number): Promise<APIResponse<boolean>> {
    return this.makeRequest(`/api/bins/${id}`, {
      method: 'DELETE',
    });
  }

  // AI methods (for later)
  async generateInsights(thoughtmarkIds?: string[]): Promise<APIResponse<any>> {
    const response = await this.makeRequest('/api/ai/insights', {
      method: 'POST',
      body: JSON.stringify({ thoughtmarkIds }),
    });
    console.log('[apiService.generateInsights] Raw response:', response);
    return {
      success: response.success,
      data: response.data,
      error: response.error,
    };
  }

  async smartSort(thoughtmarkIds?: string[]): Promise<APIResponse<any>> {
    const response = await this.makeRequest('/api/ai/smart-sort', {
      method: 'POST',
      body: JSON.stringify({ thoughtmarkIds }),
    });
    return {
      success: response.success,
      data: response.data,
      error: response.error,
    };
  }

  async recommendations(thoughtmarkIds?: string[]): Promise<APIResponse<any>> {
    const response = await this.makeRequest('/api/ai/recommendations', {
      method: 'POST',
      body: JSON.stringify({ thoughtmarkIds }),
    });
    return {
      success: response.success,
      data: response.data,
      error: response.error,
    };
  }

  async learningResources(thoughtmarkIds?: string[]): Promise<APIResponse<any>> {
    const response = await this.makeRequest('/api/ai/learning-resources', {
      method: 'POST',
      body: JSON.stringify({ thoughtmarkIds }),
    });
    return {
      success: response.success,
      data: response.data,
      error: response.error,
    };
  }

  async categorizeThoughtmark(content: string): Promise<APIResponse<string[]>> {
    return this.makeRequest('/api/ai/categorize', {
      method: 'POST',
      body: JSON.stringify({ content }),
    });
  }

  async summarizeThoughtmark(content: string): Promise<APIResponse<string>> {
    return this.makeRequest('/api/ai/summarize', {
      method: 'POST',
      body: JSON.stringify({ content }),
    });
  }

  // Voice processing (for later)
  async uploadVoiceNote(formData: FormData): Promise<APIResponse<{ url: string; transcription: string }>> {
    const token = await AsyncStorage.getItem('@thoughtmarks_token');
    
    return this.makeRequest('/api/ai/process-voice', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
      },
      body: formData,
    });
  }

  async semanticSearch(query: string) {
    const response = await this.makeRequest('/api/ai/semantic-search', {
      method: 'POST',
      body: JSON.stringify({ query }),
    });
    return {
      success: response.success,
      data: response.data,
      error: response.error,
    };
  }

  async generateSearchSuggestions() {
    const response = await this.makeRequest('/api/ai/search-suggestions', {
      method: 'POST',
    });
    return {
      success: response.success,
      data: response.data,
      error: response.error,
    };
  }

  async generateThoughtmarkSuggestions(data: { content: string; title?: string; tags?: string[] }) {
    const response = await this.makeRequest('/api/ai/thoughtmark-suggestions', {
      method: 'POST',
      body: JSON.stringify(data),
    });
    return {
      success: response.success,
      data: response.data,
      error: response.error,
    };
  }

  // Premium/StoreKit methods
  async updatePremiumStatus(data: {
    productId: string;
    transactionId: string;
    purchaseDate: string;
    expirationDate?: string;
  }): Promise<APIResponse<User>> {
    return this.makeRequest('/api/users/premium', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }
}

export const apiService = new ApiService();