# GLOBAL HYBRID BLOCK RULES — GPT ENFORCEMENT

## 📅 Effective: 2025-07-10
## Applies To:
- BRAUN (MAIN) Cursor in `/tm-mobile-cursor/mobile-native-fresh/`
- DEV (The Kid) Cursor in `/gpt-cursor-runner/`
- GHOST (Relay between GPT ↔ Cursor)

## 🔐 Hybrid Block Format
- `"showInUI": true` enforced globally
- `"parseCheck": true` + `"postMutationBuild"` typecheck required
- `"blockCommitOnError": true` — NO commits unless runtime success confirmed by GPT

## ⛔ Blockers
- GHOST must NEVER mark a patch complete
- GPT is final validator before any `*_complete` tags

## ✅ Git Hygiene Rules
- `.tar.gz` backups only at visually safe state
- Each hybrid block includes:
  - `"notes"` array (goal, mission, safeguards)
  - `"branch"` auto-created with context
  - `"tag"` only if `tsc` + runtime pass
