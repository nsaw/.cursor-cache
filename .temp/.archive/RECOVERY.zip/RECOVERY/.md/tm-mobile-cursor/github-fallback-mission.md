# GitHub Emergency Recovery Fallback Mission - 2025-07-11T06:30UTC

## 🧠 MISSION: Establish GitHub-based emergency recovery fallback for tm-mobile-cursor

## 🎯 GOAL: Ensure pipeline, tunnel, patch, and environment recovery can be triggered autonomously via GitHub Actions

## 🛡️ SCOPE: Resume pipeline, re-run watchdog, scan health, test Slack routes, backup current state, and clean patch stalls

## 📦 OUTPUT: Action script + helper workflows, logs stored in summaries/summary_*.md for webhook detection

## 🚨 SAFETY ENFORCEMENT 🚨
- ✅ All scripts must route through safe-run to prevent terminal hangs
- ✅ GitHub Action must be readonly for diagnosis steps unless authorized with OP vault token injection
- ✅ Any `.tar.gz` backups must match naming format and go to `_backups/tm-safety_backups/`
- ✅ Validate Slack endpoint only if SLACK_REDIRECT_URI is set
- 🔐 ENFORCEMENT: Protect all fallback actions from triggering pushes, deploys, or permanent changes unless GPT/Nick approve

## 📋 EXECUTION PLAN
1. **Create GitHub Actions workflow** with emergency triggers
2. **Create fallback scripts** for resume, backup, health scan
3. **Ensure safe-run routing** for all operations
4. **Set up backup naming** and storage format
5. **Configure summary output** for webhook detection

## 🔄 TRIGGERS TO IMPLEMENT
- `/resume`: restarts last patch and reloads watchdog
- `/diagnose`: triggers health scan, writes summaries/summary_health-dump_<timestamp>.md
- `/reset-patch`: clears patch temp state and restarts Cursor
- `/backup-now`: runs backup-tag-push.sh with FALLBACK_TRIGGERED_<timestamp>
- `/test-oauth`: pings SLACK_REDIRECT_URI and logs result
- `/watchdog`: calls safe-run to re-run watchdog.js check

## 📌 CONTEXT
- Used to recover from runner crash, tunnel failure, or pipeline deadlock
- Keeps dev loop flowing even if Cursor hangs or Slack tunnel is unresponsive

**Status**: Starting GitHub fallback suite creation
**Next**: Create workflow and fallback scripts

## ✅ MISSION COMPLETE
**Phase 1**: ✅ Created GitHub Actions workflow with emergency triggers
**Phase 2**: ✅ Created fallback scripts for resume, backup, health scan
**Phase 3**: ✅ Ensured safe-run routing for all operations
**Phase 4**: ✅ Set up backup naming and storage format
**Phase 5**: ✅ Configured summary output for webhook detection

## 📋 IMPLEMENTED TRIGGERS
- ✅ `/resume`: restarts last patch and reloads watchdog
- ✅ `/diagnose`: triggers health scan, writes summaries/summary_health-dump_<timestamp>.md
- ✅ `/reset-patch`: clears patch temp state and restarts Cursor
- ✅ `/backup-now`: runs backup-tag-push.sh with FALLBACK_TRIGGERED_<timestamp>
- ✅ `/test-oauth`: pings SLACK_REDIRECT_URI and logs result
- ✅ `/watchdog`: calls safe-run to re-run watchdog.js check

## 🛡️ SAFETY MEASURES IMPLEMENTED
- ✅ All scripts route through safe-run.sh with 30s timeout
- ✅ GitHub Action is readonly for diagnosis steps
- ✅ Backup naming format: `_backups/tm-safety_backups/YYYYMMDD-UTC_vX.X.X_TAG.tar.gz`
- ✅ Summary output with 'summaries/summary_*' prefix for webhook pickup
- ✅ Protected from pushes/deploys unless GPT/Nick approve

## 📁 FILES CREATED
- `.github/workflows/emergency-recovery-suite.yml`
- `scripts/github-fallback-resume.sh`
- `scripts/github-fallback-backup.sh`
- `scripts/github-fallback-healthscan.sh`
- `summaries/.gitkeep`

**Status**: GitHub fallback recovery suite fully implemented and ready for emergency use 