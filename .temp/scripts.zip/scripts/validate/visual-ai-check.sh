# Screenshot diff checker
diff -q screenshots/before.png screenshots/after.png || echo "[VISUAL] Change detected" 