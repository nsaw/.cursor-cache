#!/bin/bash

# Reinstall Slack App with New Tokens
# This script helps you reinstall the Slack app after permission scope changes

set -e

echo "🔄 Slack App Reinstallation Helper"
echo "=================================="
echo ""

# New tokens from user
SLACK_APP_ACCESS="xoxe.xoxp-1-Mi0yLTkxNzU2MzI3ODc0MDgtOTE3NTYzMjgxODc1Mi05MTU2ODcyODMwMzg2LTkyMTc1NjgzMjg1MTUtM2E2ZGFkM2QzMTgyMDFlY2VlMTFhMjc5MTg3ZGQxOTM1ZjU4ZDg4MGQ3ZDA5MTJhZTg5NTFmNzg1YTdjNjVjNg"
SLACK_APP_REFRESH="xoxe-1-My0xLTkxNzU2MzI3ODc0MDgtOTE1Njg3MjgzMDM4Ni05MjE3NTY4MzMxNDExLThjMjJlYzM0NjY5OTM2ODczNWE3MmU3YWFkNmQ3MjFkMTA1MjRkY2U2ZDYxOGRlOTY2NzNiMjhkZGFlNWVmYTU"

echo "📋 New Tokens Detected:"
echo "   App Access Token: ${SLACK_APP_ACCESS:0:20}..."
echo "   App Refresh Token: ${SLACK_APP_REFRESH:0:20}..."
echo ""

# Update environment variables
echo "🔧 Updating environment variables..."

# Function to update or add environment variable
update_env_var() {
    local key=$1
    local value=$2
    local file=".env"
    
    if grep -q "^${key}=" "$file"; then
        # Update existing variable
        if [[ "$OSTYPE" == "darwin"* ]]; then
            # macOS
            sed -i '' "s|^${key}=.*|${key}=${value}|" "$file"
        else
            # Linux
            sed -i "s|^${key}=.*|${key}=${value}|" "$file"
        fi
    else
        # Add new variable
        echo "${key}=${value}" >> "$file"
    fi
}

# Update Slack tokens
update_env_var "SLACK_APP_ACCESS" "$SLACK_APP_ACCESS"
update_env_var "SLACK_APP_REFRESH" "$SLACK_APP_REFRESH"

echo "✅ Environment variables updated!"

# Update manifest
echo "📝 Updating app manifest..."
node scripts/update_slack_manifest_cli.js

echo ""
echo "🔄 Next Steps for App Reinstallation:"
echo "====================================="
echo ""
echo "1. 📱 Go to your Slack workspace"
echo "2. 🔍 Search for 'Apps' in the sidebar"
echo "3. 📋 Find 'gpt-cursor-runner' in your apps list"
echo "4. ⚙️  Click the gear icon (Settings)"
echo "5. 🗑️  Click 'Remove app' to uninstall"
echo "6. ✅ Confirm the removal"
echo ""
echo "7. 🔗 Go to: https://api.slack.com/apps"
echo "8. 📱 Find your app (gpt-cursor-runner)"
echo "9. 🔧 Click 'Install App' in the left sidebar"
echo "10. ✅ Click 'Install to Workspace'"
echo "11. 🔐 Authorize the app with the new permissions"
echo ""
echo "12. 🧪 Test the commands:"
echo "    /dashboard"
echo "    /status-runner"
echo "    /patch-pass next"
echo ""
echo "📊 App Configuration Summary:"
echo "   • App Name: gpt-cursor-runner"
echo "   • Commands: 25 essential commands"
echo "   • Permissions: commands, chat:write, users:read, app_mentions:read, incoming-webhook, channels:history"
echo "   • Webhook: Configured and tested"
echo ""
echo "🎉 After reinstallation, all 25 commands should work properly!"
echo ""
echo "💡 If you still see permission errors, try:"
echo "   • Refreshing your Slack client"
echo "   • Waiting a few minutes for changes to propagate"
echo "   • Testing with a simple command like /dashboard" 